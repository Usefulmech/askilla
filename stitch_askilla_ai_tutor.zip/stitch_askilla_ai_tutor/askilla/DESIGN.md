---
name: Askilla
colors:
  surface: '#fcf9f8'
  surface-dim: '#dcd9d9'
  surface-bright: '#fcf9f8'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f6f3f2'
  surface-container: '#f0eded'
  surface-container-high: '#eae7e7'
  surface-container-highest: '#e4e2e1'
  on-surface: '#1b1c1c'
  on-surface-variant: '#4d463c'
  inverse-surface: '#303030'
  inverse-on-surface: '#f3f0f0'
  outline: '#7f766a'
  outline-variant: '#d0c5b7'
  surface-tint: '#725b37'
  primary: '#725b37'
  on-primary: '#ffffff'
  primary-container: '#c4a77d'
  on-primary-container: '#503c1b'
  inverse-primary: '#e1c296'
  secondary: '#745a34'
  on-secondary: '#ffffff'
  secondary-container: '#fedaaa'
  on-secondary-container: '#795e38'
  tertiary: '#635e54'
  on-tertiary: '#ffffff'
  tertiary-container: '#b2aba0'
  on-tertiary-container: '#443f37'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#fedeb0'
  primary-fixed-dim: '#e1c296'
  on-primary-fixed: '#281800'
  on-primary-fixed-variant: '#584321'
  secondary-fixed: '#ffddb1'
  secondary-fixed-dim: '#e3c193'
  on-secondary-fixed: '#291800'
  on-secondary-fixed-variant: '#5a431f'
  tertiary-fixed: '#e9e1d5'
  tertiary-fixed-dim: '#cdc6ba'
  on-tertiary-fixed: '#1e1b14'
  on-tertiary-fixed-variant: '#4b463e'
  background: '#fcf9f8'
  on-background: '#1b1c1c'
  surface-variant: '#e4e2e1'
typography:
  headline-lg:
    fontFamily: Space Grotesk
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
    letterSpacing: -0.02em
  headline-lg-mobile:
    fontFamily: Space Grotesk
    fontSize: 26px
    fontWeight: '700'
    lineHeight: 32px
    letterSpacing: -0.02em
  headline-md:
    fontFamily: Space Grotesk
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 30px
  headline-sm:
    fontFamily: Space Grotesk
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 26px
  body-lg:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-sm:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  label-md:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.05em
  citation:
    fontFamily: Inter
    fontSize: 13px
    fontWeight: '400'
    lineHeight: 18px
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  base: 8px
  xs: 4px
  sm: 12px
  md: 16px
  lg: 24px
  xl: 32px
  container-margin: 20px
  gutter: 16px
---

## Brand & Style
The design system for Askilla is rooted in the "Fresh Notebook" aesthetic—a digital interpretation of tactile, academic tools. It targets students and lifelong learners seeking a focused, warm, and approachable educational environment. 

The style merges **Minimalism** with **Tactile** influences. It avoids the sterile coldness of typical AI interfaces in favor of a "paper-and-ink" feel. The emotional response is one of calm productivity and reliability. Design elements should feel intentional, like ink on heavy-stock paper, using purposeful whitespace and subtle textural shifts to guide the user through their learning journey.

## Colors
The palette is organic and low-strain, mimicking natural materials. 
- **Cream (#F5F0E8)** serves as the primary canvas, reducing eye fatigue during long study sessions.
- **Carton Brown (#C4A77D)** and **Carton Dark (#8B6F47)** are used for primary actions and active states, providing a sophisticated, earthy contrast.
- **Ink (#2C2C2C)** is reserved for high-hierarchy headings to ensure maximum legibility.
- **Grey (#6B6B6B)** and **Grey Light (#A0A0A0)** handle secondary information and metadata, maintaining a clear visual hierarchy without cluttering the interface.

## Typography
This design system utilizes **Space Grotesk** for headings to inject a modern, slightly technical, yet quirky personality that complements the AI aspect of the app. For all reading and functional text, **Inter** is used to ensure maximum clarity and a grounded, neutral feel.

- **Headlines:** Use Ink (#2C2C2C) with tight letter-spacing to create a strong visual anchor.
- **Body Text:** Use Grey (#6B6B6B) for long-form content to soften the reading experience.
- **Citations:** Use Grey Light (#A0A0A0) in the `citation` style to clearly distinguish AI-generated references from the main conversation.

## Layout & Spacing
The layout follows a **Fluid Grid** model optimized for mobile-first interaction. 
- **Margins:** A standard 20px horizontal margin is maintained on all screens to create breathing room.
- **Rhythm:** An 8px linear scale governs all padding and vertical spacing to maintain a mathematical harmony reminiscent of ruled paper.
- **Reflow:** On larger mobile devices or tablets, content containers should maintain a maximum width of 600px to keep line lengths readable for educational content.

## Elevation & Depth
Depth in this design system is achieved through **Tonal Layers** and **Subtle Outlines** rather than heavy shadows. 
- **Surface 1 (Base):** Cream (#F5F0E8) for the main application background.
- **Surface 2 (Containers):** Cream Dark (#E8E0D4) for input fields, cards, and secondary sections. This creates a "recessed" or "stacked paper" effect.
- **Interactive Depth:** When a card is active or "slid up," a very soft, low-opacity shadow (#8B6F47 at 10% opacity) may be applied to suggest it is hovering just above the notebook surface.
- **Borders:** Use 1px solid borders in Cream Dark for structural definition on the base surface.

## Shapes
The shape language is **Rounded**, reflecting a friendly and safe learning environment. 
- **Standard Radius:** 0.5rem (8px) for primary buttons and input fields.
- **Large Radius:** 1rem (16px) for cards and modals to emphasize the "notebook" feel.
- **Pill Shapes:** Used exclusively for badges and tags to distinguish them from actionable buttons.

## Components
- **Buttons:** Primary buttons use Carton Brown (#C4A77D) with Ink or White text. Use a slight scale-down transform (0.98) on press for a tactile feel.
- **Slide-up Cards:** Modals and bottom sheets must use a transition from Y: 16px to 0px with an 0.3s ease-out curve. This simulates placing a new sheet of paper on the desk.
- **Input Fields:** Styled with Cream Dark (#E8E0D4) backgrounds. The active state should use a 1.5px border of Carton Dark (#8B6F47).
- **Progress Bars:** Use a smooth linear transition. The track is Cream Dark, and the fill is Carton Brown.
- **Badges:** Feature a "gentle pulse" animation (opacity 1.0 to 0.7) for status indicators or active AI citations to draw attention without distraction.
- **Footer:** Every main screen must include a centered "3MTT Knowledge Showcase 2.0" label in the `label-md` typography style using Grey Light (#A0A0A0).
- **Lists:** Separated by thin 1px Cream Dark lines, with ample vertical padding (16px) to ensure touch targets are accessible.
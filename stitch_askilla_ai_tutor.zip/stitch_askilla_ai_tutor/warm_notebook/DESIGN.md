---
name: Warm Notebook
colors:
  surface: '#fafaf5'
  surface-dim: '#dadad5'
  surface-bright: '#fafaf5'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f4f4ef'
  surface-container: '#eeeee9'
  surface-container-high: '#e8e8e3'
  surface-container-highest: '#e3e3de'
  on-surface: '#1a1c19'
  on-surface-variant: '#50453b'
  inverse-surface: '#2f312e'
  inverse-on-surface: '#f1f1ec'
  outline: '#827569'
  outline-variant: '#d4c4b7'
  surface-tint: '#7c572d'
  primary: '#7c572d'
  on-primary: '#ffffff'
  primary-container: '#d4a574'
  on-primary-container: '#5b3a13'
  inverse-primary: '#efbd8a'
  secondary: '#5f5e5e'
  on-secondary: '#ffffff'
  secondary-container: '#e4e2e1'
  on-secondary-container: '#656464'
  tertiary: '#3a6477'
  on-tertiary: '#ffffff'
  tertiary-container: '#8ab4ca'
  on-tertiary-container: '#194659'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#ffdcbc'
  primary-fixed-dim: '#efbd8a'
  on-primary-fixed: '#2c1700'
  on-primary-fixed-variant: '#614018'
  secondary-fixed: '#e4e2e1'
  secondary-fixed-dim: '#c8c6c6'
  on-secondary-fixed: '#1b1c1c'
  on-secondary-fixed-variant: '#474747'
  tertiary-fixed: '#bfe8ff'
  tertiary-fixed-dim: '#a2cde3'
  on-tertiary-fixed: '#001f2a'
  on-tertiary-fixed-variant: '#204c5f'
  background: '#fafaf5'
  on-background: '#1a1c19'
  surface-variant: '#e3e3de'
typography:
  headline-xl:
    fontFamily: Plus Jakarta Sans
    fontSize: 48px
    fontWeight: '700'
    lineHeight: '1.1'
    letterSpacing: -0.02em
  headline-xl-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 32px
    fontWeight: '700'
    lineHeight: '1.2'
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 32px
    fontWeight: '600'
    lineHeight: '1.2'
  headline-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 24px
    fontWeight: '600'
    lineHeight: '1.3'
  body-lg:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '400'
    lineHeight: '1.6'
  body-md:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: '1.5'
  label-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '600'
    lineHeight: '1.4'
    letterSpacing: 0.01em
  label-sm:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '500'
    lineHeight: '1.4'
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  base: 8px
  container-padding: 24px
  gutter: 16px
  margin-mobile: 16px
  margin-desktop: 40px
---

## Brand & Style

The design system is built on a "warm notebook" aesthetic, designed to evoke a sense of calm, focus, and tactile reliability. It targets an audience that appreciates clarity and warmth over clinical tech aesthetics. 

The style is a blend of **Minimalism** and **Tactile Modernism**. It avoids digital-first tropes like vibrant neon or heavy shadows in favor of a flat, structured layout that mimics high-quality stationery. The emotional response should be one of "digital comfort"—a clean, inviting space for thought and action. The system is strictly limited to three colors to ensure maximum cohesion and a disciplined visual hierarchy.

## Colors

The palette is intentionally restrictive to maintain a specific atmosphere. No gradients, transparency-based tints, or additional shades are permitted.

- **Background (#F5F5F0):** A warm grey that serves as the canvas for all interfaces. It provides a softer contrast than pure white, reducing eye strain and reinforcing the paper-like feel.
- **Text (#2D2D2D):** Used for all typography, icons, and structural borders. This near-black provides grounded legibility.
- **Action/Accent (#D4A574):** A warm light brown reserved exclusively for interactive elements, highlights, and primary calls to action.

## Typography

The typography strategy pairs the friendly, modern geometric forms of **Plus Jakarta Sans** for headings with the functional, neutral clarity of **Inter** for body copy and UI labels.

Headlines should use tighter letter spacing to feel "locked in," while body text maintains a generous line height to enhance the comfortable reading experience of the notebook theme. All text must be rendered in the primary text color (#2D2D2D), with the exception of button labels on accent backgrounds which may remain the text color for a high-contrast, "stamped" look.

## Layout & Spacing

The layout follows a **Fluid Grid** model with a strong emphasis on generous white space (the warm grey background). 

- **Desktop:** 12-column grid with 24px gutters.
- **Tablet:** 8-column grid with 16px gutters.
- **Mobile:** 4-column grid with 16px gutters and 16px side margins.

Spacing follows an 8px linear scale. Large containers and sections should utilize the "container-padding" token (24px) to ensure content feels framed rather than crowded. Alignment should be crisp and rhythmic, avoiding complex offsets to maintain the minimalist aesthetic.

## Elevation & Depth

This design system eschews shadows and blurs entirely. Depth is achieved through **Bold Borders** and **Tonal Layering**.

- **Level 0 (Base):** The #F5F5F0 background.
- **Level 1 (Cards/Containers):** Outlined with a 1px or 2px solid border of #2D2D2D. 
- **Level 2 (Interaction):** Elements "lift" by increasing border thickness or filling with the Accent color (#D4A574).

Interactive states do not use glows; instead, use a simple "inverse" or "fill" logic. Surfaces are flat, and hierarchy is communicated strictly through the weight of the near-black strokes and the placement of the accent color.

## Shapes

The shape language is the core of the "warmth" in this system. It utilizes high-radius corners to soften the strict three-color palette.

- **Cards:** 16px radius. Used for content blocks and modular items.
- **Containers:** 24px radius. Used for main layout wrappers and modal overlays.
- **Buttons/Pills:** 999px radius (Full Round). All interactive triggers, tags, and chips must use the pill shape.

Every border must be a solid stroke of #2D2D2D. The consistent use of rounded forms against the stark color palette creates a friendly yet professional "designer stationery" appearance.

## Components

### Buttons
Primary buttons are filled with #D4A574 with #2D2D2D text. They are always 999px pill-shaped. Secondary buttons are outlined with #2D2D2D (1px) with no fill.

### Cards
Cards use a 16px border radius and a 1px solid #2D2D2D border. There is no background change within the card—it remains #F5F5F0 to keep the "sheet of paper" look.

### Input Fields
Inputs are 999px pill-shaped with a 1px solid #2D2D2D border. Focus states increase the border to 2px or change the border color to #D4A574.

### Chips & Tags
Always 999px pill-shaped. For categories, use an outline. For active filters, use the #D4A574 fill.

### Lists
List items are separated by a 1px horizontal line of #2D2D2D. No bullets; use small #D4A574 squares or the accent color for icons to denote list items.

### Checkboxes & Radios
Checkboxes should be slightly rounded (4px) to contrast with the otherwise very round UI. Radios remain perfectly circular. Both use a #2D2D2D stroke and #D4A574 fill when selected.